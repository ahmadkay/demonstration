-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 07, 2019 at 02:01 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `abi`
--

-- --------------------------------------------------------

--
-- Table structure for table `allocation`
--

CREATE TABLE `allocation` (
  `id` int(4) NOT NULL auto_increment,
  `teacher` varchar(100) NOT NULL,
  `class` varchar(50) NOT NULL,
  `subject` varchar(70) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `allocation`
--

INSERT INTO `allocation` (`id`, `teacher`, `class`, `subject`) VALUES
(1, '3', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `id` int(4) NOT NULL auto_increment,
  `assignment` varchar(300) NOT NULL,
  `url` varchar(200) NOT NULL,
  `subjectid` int(4) NOT NULL,
  `assignmentdate` varchar(20) NOT NULL,
  `subdate` varchar(20) NOT NULL,
  `assignmentfor` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`id`, `assignment`, `url`, `subjectid`, `assignmentdate`, `subdate`, `assignmentfor`) VALUES
(1, 'ali 404.docx', 'localhost/Abiassignment/ali 404.docx', 2, '2019-09-13', '2019-09-20', ''),
(2, 'ali 404.docx', 'http://localhost/Abiassignment/ali 404.docx', 2, '2019-09-13', '2019-09-20', ''),
(3, 'ali 404.docx', 'http://localhost/Abiassignment/ali 404.docx', 2, '2019-09-13', '2019-09-20', '');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(4) NOT NULL auto_increment,
  `class` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `class`) VALUES
(1, 'jss1'),
(2, 'jss2'),
(3, 'jss3'),
(4, 'ss1'),
(5, 'ss2'),
(6, 'ss3');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(4) NOT NULL auto_increment,
  `userid` int(4) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `date_of_birth` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `parentname` varchar(50) NOT NULL,
  `parentaddres` varchar(250) NOT NULL,
  `parentnumber` varchar(11) NOT NULL,
  `sponsorname` varchar(50) NOT NULL,
  `sponsoraddres` varchar(250) NOT NULL,
  `sponsornumber` varchar(11) NOT NULL,
  `parentemail` varchar(50) NOT NULL,
  `sponsoremail` varchar(50) NOT NULL,
  `passport` varchar(100) NOT NULL,
  `enteryclass` varchar(20) NOT NULL,
  `yearforgraduation` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `userid`, `surname`, `lastname`, `sex`, `date_of_birth`, `email`, `parentname`, `parentaddres`, `parentnumber`, `sponsorname`, `sponsoraddres`, `sponsornumber`, `parentemail`, `sponsoremail`, `passport`, `enteryclass`, `yearforgraduation`, `session`) VALUES
(7, 30, 'usman', 'aliyu', 'male', '1999-08-13', 'useey12@gmail.com', 'aliyu', 'rafin atiku opposite harmony school', '09045234588', 'aliyu usman', 'rafin atiku opposite harmony school', '09045234588', 'aliyum@yahoo.com', 'aliyum@yahoo.com', 'image5.jpg', 'jss1', '2023', '2018/2019'),
(8, 31, 'umar', 'haleema', 'female', '2003-06-21', 'halims@hotmail.com', 'umar abdullahi kangiwa', 'festac road badarawa kaduna', '08096403074', 'abubakar umar', 'layin falke bayan filin sukuwa birnin kebbi', '07060873337', 'umarkangiwa@gmail.com', 'umar.abubakar@fubk.edu.ng', 'image5.jpg', 'ss1', '2020', '2018/2019'),
(9, 32, 'benjamin', 'olamide', 'male', '1994-05-18', 'olamideben@yahoo.com', 'oyepfabi benjamin', 'badariya birnin kebbi', '07066541322', 'oyefabi benjamin', 'badariya birnin kebbi', '07066541322', 'oyefabi@gmail.com', 'oyefabi@gmail.com', 'image4.jpg', 'jss2', '2021', '2018/2019'),
(10, 33, 'adamu', 'saleh', 'male', '2005-09-21', 'adamusaleh15@gmail.com', 'adamu umar', 'yar yara area b.kebbi', '070789r459', 'adamu musa', 'badarawa kaduna', '09076887688', 'adams@gmail.com', 'admusa@gmail.com', 'image9.jpg', 'jss1', '2020', '2018/2019'),
(11, 34, 'balarabe', 'maryam', 'female', '2000-08-06', 'maryambk@gmail.com', 'balarabe anas', 'unguwan rimi near police station kaduna', '08078059449', 'aliyu aminu', 'kalgo near central mosque kebbi state', '07094984485', 'anasbalarabe@gmail.com', 'aliyuamin@yahoo.com', 'image3.jpg', 'ss2', '2021', '2018/2019'),
(12, 35, 'aliyu', 'nadia', 'female', '2002-08-26', 'mamaa11@gmail.com', 'aliyu musa', 'bayan zinari hotel birnin kebbi', '07066959599', 'aliyu musa', 'bayan zinari hotel birnin kebbi', '07066959599', 'musaali@gmail.com', 'musaali@gmail.com', 'image8.jpg', 'ss1', '2022', '2018/2019'),
(13, 36, 'ibrahim', 'muhahammad', 'male', '2002-01-26', 'mohaib@yahoo.com', 'muhammad sani', 'farouk lane badariya birnin kebbi', '09045678833', 'muhammad sani', 'farouk lane badariya birnin kebbi', '09045678833', 'sanimuhammd@gmail.com', 'sanimuhammd@gmail.com', 'image3.jpg', 'ss2', '2020', '2018/2019'),
(14, 37, 'ahmad', 'nana aisha', 'female', '2004-08-05', 'nanaaisha12@gmail.com', 'ahmad rufa''i umar', 'bayan filin sukuwa birnin kebbi', '07036126262', 'abubakar umar', 'bayan filin sukuwa birnin kebbi', '07060873337', 'ahmadkiassa@gmail.com', 'abubakar180umar@gmail.com', 'image5.jpg', 'jss1', '2022', '2018/2019'),
(15, 38, 'bala', 'buhari', 'male', '2003-08-20', 'buhareebala@gmail.com', 'bala muhammad', 'badaria near gari mallan house', '09080706050', 'bala muhammad', 'badaria near gari mallan house', '09080706050', 'balamuhd@yahoo.com', 'balamuhd@yahoo.com', 'image5.jpg', 'ss1', '2023', '2018/2019'),
(16, 39, 'umar', 'abubakar', 'male', '2004-08-02', 'abubakar180umar@gmail.com', 'umar abdullahi kangiwa', 'festac road badaraw kaduna', '08097557001', 'umar abdullahi kangiwa', 'festac road badaraw kaduna', '08097557001', 'abdullahikangiwa@gmail.com', 'abdullahikangiwa@gmail.com', 'image6.jpg', 'ss1', '2020', '2018/2019');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(4) NOT NULL auto_increment,
  `userid` int(4) NOT NULL,
  `subjectid` int(4) NOT NULL,
  `ca` int(10) NOT NULL,
  `exam` int(10) NOT NULL,
  `total` int(100) NOT NULL,
  `class` varchar(5) NOT NULL,
  `term` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `results`
--


-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `id` int(4) NOT NULL auto_increment,
  `section` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`id`, `section`) VALUES
(1, 'junior'),
(2, 'science'),
(3, 'art');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(4) NOT NULL auto_increment,
  `subject` varchar(70) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subject`) VALUES
(1, 'Mathematics'),
(2, 'English'),
(3, 'Physics'),
(4, 'Chemistry'),
(5, 'Biology'),
(6, 'Geography'),
(7, 'Economics'),
(8, 'Agric Science'),
(9, 'Basics Scince'),
(10, 'Social Studies'),
(11, 'Government'),
(12, 'History'),
(13, 'Computer studies'),
(14, 'Business Studies'),
(15, 'Introduction  Technology'),
(16, 'Christian religrous Studies'),
(17, 'Islamic Studies'),
(18, 'Literature'),
(19, 'Marketing'),
(20, 'Animal Husbandary'),
(21, 'P.H.E');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(4) NOT NULL auto_increment,
  `userid` int(4) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `date_of_birth` varchar(50) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `address` varchar(300) NOT NULL,
  `classname` varchar(50) NOT NULL,
  `subjectname` varchar(100) NOT NULL,
  `yearjoin` varchar(50) NOT NULL,
  `session` varchar(50) NOT NULL,
  `passport` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `userid`, `surname`, `lastname`, `date_of_birth`, `phonenumber`, `email`, `sex`, `address`, `classname`, `subjectname`, `yearjoin`, `session`, `passport`) VALUES
(3, 25, 'sani', 'musa aliyu', '2019-07-31', '09067899900', 'bala@gmail.com', 'male', 'bayan kara', '', '', '2018', '2018/2019', 'image2.jpg'),
(4, 26, 'usman', 'ghali', '1988-08-02', '08097945634', 'usmam180@yahoo.com', 'male', 'badariya opposite abi private school', '', '', '2013', '2018/2019', 'image1.jpg'),
(5, 27, 'fatima', 'aliyu', '1992-07-02', '07033844833', 'fatya@gmail.com', 'female', 'bayan filin sukuwa area birnin kebbi', '', '', '2017', '2018/2019', 'image19.jpg'),
(6, 28, 'aliyu', 'hadiza', '1998-04-07', '08133483455', 'alihadiza@gmail.com', 'female', 'aleiru quarters birnin kebbi', '', '', '2014', '2018/2019', 'image10.jpg'),
(7, 29, 'musa', 'aisha', '1990-06-07', '09088888878', 'aisha123@gmail.com', 'female', 'tudun wada birnin kebbi', '', '', '2016', '2018/2019', 'image3.jpg'),
(8, 43, 'umar', 'Ben', '2019-09-28', '07060873337', 'aa@gmail.com', 'male', 'kkkkk', '2', '2', '2018', '2018/2019', 'image1.jpg'),
(9, 48, 'kasimu', 'sadiya', '2019-09-30', '07089345678', 'sadiya12@gmail.com', 'female', 'kkkk', '', '', '2014', '2018/2019', 'IMG_20190303_135301.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` int(4) NOT NULL,
  `status` varchar(15) NOT NULL,
  `datejoint` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`, `datejoint`) VALUES
(1, 'admin', 'admin', 1, 'active', '0000-00-00 00:00:00'),
(10, 'ola@gmail.com', 'ola', 2, 'active', '2019-08-26 21:08:34'),
(22, 'abubakar180umar@gmai', 'umar', 3, 'active', '2019-08-27 15:19:43'),
(23, 'abubakar180umar@gmai', 'umar', 2, 'active', '2019-08-27 16:28:04'),
(24, 'abubakar180umar@gmai', 'umar', 2, 'active', '2019-08-27 16:31:01'),
(25, 'bala@gmail.com', 'sani', 3, 'active', '2019-08-27 16:44:31'),
(26, 'usman180@yahoo.com', 'usman', 3, 'active', '2019-08-27 16:50:11'),
(27, 'fatya@gmail.com', 'fatima', 3, 'active', '2019-08-27 16:53:24'),
(28, 'alihadiza@gmail.com', 'aliyu', 3, 'active', '2019-08-27 16:55:50'),
(29, 'aisha123@gmail.com', 'musa', 3, 'active', '2019-08-27 16:57:32'),
(30, 'useey12@gmail.com', 'usman', 2, 'active', '2019-08-27 17:01:51'),
(31, 'halims@hotmail.com', 'umar', 2, 'active', '2019-08-27 17:07:59'),
(32, 'olamideben@yahoo.com', 'benjamin', 2, 'active', '2019-08-27 17:13:31'),
(33, 'adamusaleh15@gmail.c', 'adamu', 2, 'active', '2019-08-27 17:16:53'),
(34, 'maryambk@gmail.com', 'balarabe', 2, 'active', '2019-08-27 17:20:20'),
(35, 'mamaa11@gmail.com', 'aliyu', 2, 'active', '2019-08-27 17:22:45'),
(36, 'mohaib@yahoo.com', 'ibrahim', 2, 'active', '2019-08-27 17:25:46'),
(37, 'nanaaisha12@gmail.co', 'ahmad', 2, 'active', '2019-08-27 17:29:06'),
(38, 'buhareebala@gmail.co', 'bala', 2, 'active', '2019-08-27 17:31:38'),
(39, 'abubakar180umar@gmai', 'umar', 2, 'active', '2019-08-27 17:35:49'),
(40, 'aaa@gmail.com', 'adnan', 3, 'active', '2019-09-01 16:17:25'),
(41, 'aaa@gmail.com', 'hhhhh', 3, 'active', '2019-09-01 16:21:19'),
(42, 'aa@gmail.com', 'iii', 3, 'active', '2019-09-01 16:23:43'),
(43, 'aa@gmail.com', 'umar', 3, 'active', '2019-09-01 16:27:14'),
(44, 'ola@gmail.com', 'musty', 3, 'active', '2019-09-01 16:30:12'),
(45, 'aa@gmail.com', 'mmm', 3, 'active', '2019-09-01 16:58:51'),
(48, 'sadiya12@gmail.com', 'kasimu', 3, 'active', '2019-09-05 12:40:13');
